<?php echo $_SERVER['REQUEST_METHOD'] ?>
